# Кольт

A Pen created on CodePen.io. Original URL: [https://codepen.io/kuzminka/pen/xxygPWa](https://codepen.io/kuzminka/pen/xxygPWa).

